import React, { Component } from 'react'

export default class LeaveApplication extends Component {
    render() {
        return (
            <div>
                LeaveApplication
            </div>
        )
    }
}
