
import React, { Component } from 'react'
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'
import userpic from './image/userpic.png';
import axios from 'axios';
import Loginimage from './image/Loginimage.jpg';
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';


export default class ManagerLogin extends Component {
    constructor(props)
    {
        super(props);
        this.state={
            Manager:[],
            ManagerEmailId:"",
            ManagerPassword:"",
            Emailerror:"",
            Passworderror:"",
           
        }
        this.Loginsubmit=this.Loginsubmit.bind(this);
        this.validate=this.validate.bind(this);
        this.handleChange=this.handleChange.bind(this);
    }
    validate()
    {
       if(this.state.ManagerEmailId=="" && this.state.ManagerPassword=="")
       {
           alert("Pls enter mail id and password");
           
       } 
       else if(this.state.ManagerEmailId=="")
       {
           this.setState({Emailerror:"Pls enter email id"});
       }
       else if(this.state.ManagerPassword=="")
       {
           this.setState({Passworderror:"Pls enter password"});
       }
       else if(!this.state.ManagerEmailId.includes("@"))
       {
          this.setState({Emailerror:"Email must have @"});
          
       }
       else
       {
           return null;
       }
    }

Loginsubmit()
{
    this.validate();
    axios.get('http://localhost:20969/api/Manager/'+this.state.ManagerEmailId+'/'+this.state.ManagerPassword)
    .then(res=>res)
    .then(result=>{
        let r=result.data;
        
        
        if(r!=null){
                
            sessionStorage.setItem("MangId",result.data.managerId);
            sessionStorage.setItem("Mangname",result.data.fullName);
            sessionStorage.setItem("email",result.data.ManagerEmailId);
                alert("Welcome " + result.data.fullName);
            window.location="./ManagerDashBoard";
        }
        else
        {
            alert("Invalid username and password");
        }
       
    }).catch(err=>{
        alert("enter valid data");
    });
}
handleChange(e)
{
    this.setState(e);
}
    


render() {
    return (
        <div>
            <>
               <Container className="mt-5">
                   <Row>
                       <Col lg={4} md={6} sm={12} className="text-center mt-5 p-18">
                           <img className="icon" src={userpic} alt="icon"/>
                       <Form>
                           <FormLabel className="h">Manager Login Page</FormLabel>
      <Form.Group className="mb-3" controlId="formBasicEmail">
       
        <Form.Control type="email" onChange={(e)=>this.handleChange({ManagerEmailId:e.target.value})} placeholder="Enter email" />
        <p >{this.state.Emailerror}</p>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        
        <Form.Control type="password" onChange={(e)=>this.handleChange({ManagerPassword:e.target.value})} placeholder="Password" />
        <p >{this.state.Passworderror}</p>
      </Form.Group>
      
      <Button variant="primary btn-block" onClick={this.Loginsubmit} type="submit"> Login </Button>
      <div>
          Don't have an account yet?
          <Link to="/ManagerRegister"> Register here</Link>
      </div>
      
    </Form>
                       </Col>
                       <Col lg={8} md={6} sm={12}>
                        <img className="w100" src={Loginimage} alt=""/>
                       </Col>

                   </Row>
               </Container>
               </>
        </div>
    )
}
}

