import axios from 'axios';
import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'

export default class MyManagerDetails extends Component {
constructor(props)
{
        super(props);
        this.state={
            Manager:[],
            managerId:"",
            managerPassword:"",
            fullName:"",
            managerEmailId:"",
            managerMobileNo:"",
        

        }
        this.SearchById=this.SearchById.bind(this);
        this.handleChange=this.handleChange.bind(this);
        this.SignOut=this.SignOut.bind(this);
        this.Back=this.Back.bind(this);
       
}
SearchById()
{
    let id=sessionStorage.getItem("MangId");
    let url="http://localhost:20969/api/Manager/"+id;
    axios.get(url).then(response=>{
        this.setState({
            managerId:response.data.managerId,
            managerPassword:response.data.managerPassword,
            fullName:response.data.fullName,
            managerEmailId:response.data.managerEmailId,
            managerMobileNo:response.data.managerMobileNo,
        })
    }).catch(err=>{
        console.warn(err);
    })
    if(id==null)
        {
            alert("Pls Login First");
            window.location="/EmpLogin";
        }
}
SignOut()
    {
       
        sessionStorage.removeItem("MangId");
        
        sessionStorage.removeItem("email");
        window.location="/EmpLogin";

    }

handleChange(e)
{
    this.setState(e);
}
componentDidMount()
{
    this.SearchById();
   
        
    
}
Back()
{
    window.location='./EmpDashBoard';
}


    render() {
        const {managerId}=this.state;
        const {employeePassword}=this.state;
        const {fullName}=this.state;
        const {managerEmailId}=this.state;
        const {managerMobileNo}=this.state;
        
        return (
            <div>
                Id={managerId}<br></br>
                FullName={fullName}<br></br>
                {/* Password={employeePassword}<br></br> */}
                EmailId={managerEmailId}<br></br>
                Mobile number={managerMobileNo}<br></br>
                
                {/* <button type="submit" onClick={this.SearchById}>Profile</button> */}
                <Button variant="primary btn-block" onClick={this.Back} type="submit"> Back to DashBoard </Button>
                <Button variant="primary btn-block" onClick={this.SignOut} type="submit"> SignOut </Button>

               
            </div>
        )
    }
}

