import axios from 'axios';
import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';


export default class EditManager extends Component {
constructor(props)
{
        super(props);
        this.state={
            ManagerPassword:"",
            FullName:"",
            ManagerEmailId:"",
            ManagerMobileNo:"",
            

        }
        this.Update=this.Update.bind(this);
        this.handleChange=this.handleChange.bind(this);

}
handleChange(e)
{
    this.setState(e);
}
Update()
{
    let id=sessionStorage.getItem("MangId");
    let url="http://localhost:20969/api/Manager/"+id;
    axios.put(url,{
        FullName:this.state.FullName,
        ManagerPassword:this.state.ManagerPassword,
        ManagerEmailId:this.state.ManagerEmailId,
        ManagerMobileNo:this.state.ManagerMobileNo,
        
    }).then(response=>{
        alert("Data Updated Successfully");
        window.location="./Profile";
    }).catch(err=>{
        alert(err);
    })
    
}
    
    render() {
        return (
            <div>
                <div className="background">
            <div  >
                
                
                <form className="box" >
                <h2 className="h2">Edit Profile</h2>
                   <div >
                       
                        {/* <lable className="lable"> Id</lable> */}
                        {/* <input type="number" name="EmployeeId" placeholder=" Enter your id"></input>
                        <br/> */}
                        <label>FullName</label>
                        <input type="text" name="FullName" onChange={(e)=>this.handleChange({FullName:e.target.value})} placeholder=" Enter your Name"></input>
                        <br/>
                        <label>Password</label>
                        <input type="password" name="ManagerPassword" onChange={(e)=>this.handleChange({ManagerPassword:e.target.value})} placeholder=" Enter your password"></input>
                        <br/>
                        <label>EmailId</label>
                        <input type="emailid" name="ManagerEmailId" onChange={(e)=>this.handleChange({ManagerEmailId:e.target.value})}placeholder=" Enter your EmailId"></input>
                        <br/>
                        <label>MobileNo</label>
                        <input type="text" name="ManagerMobileNo" onChange={(e)=>this.handleChange({ManagerMobileNo:e.target.value})} placeholder=" Enter your Mobile number"></input>
                        <br/>
                       
                        <button type="submit" className="button" onClick={this.Update} >Save Changes</button>
                    </div>
                    
                </form>
                
            </div>
            </div>
                
            </div>
        )
    }
}
