import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'




export default class ManagerDashBoard extends Component {
    constructor()
    {
        super();
        this.state={
            Employee:[],
            Id:""

        }
        this.SignOut=this.SignOut.bind(this);
    }
    SignOut()
    {
        
        sessionStorage.removeItem("MangId");
        sessionStorage.removeItem("Mangname");
        sessionStorage.removeItem("email");
        window.location="/ManagerLogin";

    }
    componentDidMount()
    {
        let MgId=sessionStorage.getItem("MangId");
        let name=sessionStorage.getItem("Mangname");
        let email=sessionStorage.getItem("email");
        if(this.email==null)
        {
            alert("Pls Login First");
            window.location="/ManagerLogin";
        }
    }

    render() {
           this.id=sessionStorage.getItem("MangId");
            this.name=sessionStorage.getItem("Mangname");
            this.email=sessionStorage.getItem("email");
        return (
            <div>
                    Welcome {this.name},
            
            <div>
                 <Link to="/Profile">MyProfile</Link><br></br>
                
                 
                 <Link to="/LeaveApplications">LeaveApplications</Link><br></br>
                 <Button variant="primary btn-block" onClick={this.SignOut} type="submit"> SignOut </Button>
            </div>

            </div>
        )
    }
}
