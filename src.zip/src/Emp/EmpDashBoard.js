import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'
import EmpLogin from './EmpLogin';
import './EmpDashBoard.css';



export default class EmpDashBoard extends Component {
    constructor()
    {
        super();
        this.state={
            Employee:[],
            Id:""

        }
        this.SignOut=this.SignOut.bind(this);
    }
    SignOut()
    {
        sessionStorage.removeItem("EmpId");
        sessionStorage.removeItem("MangId");
        sessionStorage.removeItem("Empname");
        sessionStorage.removeItem("email");
        window.location="/EmpLogin";

    }
    componentDidMount()
    {
        let Id=   sessionStorage.getItem("EmpId");
        let MgId=sessionStorage.getItem("MangId");
        let name=sessionStorage.getItem("Empname");
        let email=sessionStorage.getItem("email");
        if(this.email==null)
        {
            alert("Pls Login First");
            window.location="/EmpLogin";
        }
    }

    render() {
           this.id=sessionStorage.getItem("EmpId");
            this.name=sessionStorage.getItem("Empname");
            this.email=sessionStorage.getItem("email");
        return (
            <body>
            <nav>
            <div >
              <label>DashBoard Welcome {this.name},</label>
             
              <Button variant="primary btn-block" onClick={this.SignOut} type="submit" > SignOut </Button>
             </div>
             </nav>
            
            <div className="container" >
                <div className="yah">
               <Link to="/MyProfile" className="punith">MyProfile</Link> <br></br>
               </div>
                <div className="yah">
               <Link to="/MyManagerDetails" className="punith" >MyManagerDetails</Link><br></br>
               </div>
               <div className="yah">
                <Link to="/LeaveTracker" className="punith">LeaveTracker</Link><br></br>
                </div>
                
                
            </div>

            
            
            </body>
            
        )
    }
}
