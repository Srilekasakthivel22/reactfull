import axios from 'axios';
import React, { Component } from 'react'
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import { Container,Button,Col,Form,Row, FormLabel} from 'react-bootstrap'
import './MyProfile.css';


export default class MyProfile extends Component {
constructor(props)
{
        super(props);
        this.state={
            Employee:[],
            employeeId:"",
            employeePassword:"",
            fullName:"",
            employeeEmailId:"",
            employeeMobileNo:"",
            employeeDoj:"",
            employeeDept:"",
            managerId:""

        }
        this.SearchById=this.SearchById.bind(this);
        this.handleChange=this.handleChange.bind(this);
        this.SignOut=this.SignOut.bind(this);
       
}
SearchById()
{
    let id=sessionStorage.getItem("EmpId");
    let url="http://localhost:20969/api/Employee/"+id;
    axios.get(url).then(response=>{
        this.setState({
            employeeId:response.data.employeeId,
            employeePassword:response.data.emplyeePassword,
            fullName:response.data.fullName,
            employeeEmailId:response.data.employeeEmailId,
            employeeMobileNo:response.data.employeeMobileNo,
            employeeDoj:response.data.employeeDoj,
            employeeDept:response.data.employeeDept,
            managerId:response.data.managerId
        })
    }).catch(err=>{
        console.warn(err);
    })
    if(id==null)
        {
            alert("Pls Login First");
            window.location="/EmpLogin";
        }
}
SignOut()
    {
        sessionStorage.removeItem("EmpId");
        sessionStorage.removeItem("MangId");
        sessionStorage.removeItem("Empname");
        sessionStorage.removeItem("email");
        window.location="/EmpLogin";

    }

handleChange(e)
{
    this.setState(e);
}
componentDidMount()
{
    this.SearchById();
   
        
    
}


    render() {
        const {employeeId}=this.state;
        const {employeePassword}=this.state;
        const {fullName}=this.state;
        const {employeeEmailId}=this.state;
        const {employeeMobileNo}=this.state;
        const {employeeDoj}=this.state;
        const {employeeDept}=this.state;
        const {managerId}=this.state;
        return (
            <div >
                <div className="back">
                <form className="leaf">
                    <label>My Details</label><br></br>
             <div className="t">   
                EmployeeId    ={employeeId}<br></br>
                FullName      ={fullName}<br></br>
                {/* Password={employeePassword}<br></br> */}
                EmailId       ={employeeEmailId}<br></br>
                Mobile number={employeeMobileNo}<br></br>
                Doj          ={employeeDoj}<br></br>
                Dept         ={employeeDept}<br></br>
                ManagerId    ={managerId}<br></br>
                {/* <button type="submit" onClick={this.SearchById}>Profile</button> */}
                <Button variant="primary btn-block" onClick={this.SignOut} type="submit"> SignOut </Button>

                <Link to="/EditProfile" >EditProfile</Link>
                </div>
                </form>
                </div>
            </div>
        )
    }
}
